#!/usr/bin/python

from wifite import wifite

wifite.run()
